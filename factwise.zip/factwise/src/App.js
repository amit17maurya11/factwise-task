import logo from './logo.svg';
import './App.css';
import Fact from './Fact';

function App() {
  return (
    <div className="App">
     
     <Fact/>
     
    </div>
  );
}

export default App;
